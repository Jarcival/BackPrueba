module.exports = [
            {
              id: 1,
              text: "¿Que pokemon es de fuego?",
              options: ["bulbasaur", "squirtle", "charmander", "pikachu"],
              correct: "charmander"
            },
            {
              id: 2,
              text: "¿Super herore no tiene poderes?",
              options: ["Flash", "MujerMaravilla", "Batman", "Superman"],
              correct: "Batman"
            },
            {
              id: 3,
              text: "¿Que tortuga nija tiene el color azul",
              options: ["donatelo", "leo", "rafa", "mickey"],
              correct: "leo"
            }
          ]